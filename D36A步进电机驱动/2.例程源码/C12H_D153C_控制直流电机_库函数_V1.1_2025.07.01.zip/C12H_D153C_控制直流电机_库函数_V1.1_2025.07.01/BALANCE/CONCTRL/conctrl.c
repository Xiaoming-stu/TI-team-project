#include "conctrl.h"

int TIM2_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
		Count++;
		if(Count>=200)
		{
			MotorAB_Mode=~MotorAB_Mode;
			Count=0;
			LED=~LED;
		}
	}
	return 0;
}




