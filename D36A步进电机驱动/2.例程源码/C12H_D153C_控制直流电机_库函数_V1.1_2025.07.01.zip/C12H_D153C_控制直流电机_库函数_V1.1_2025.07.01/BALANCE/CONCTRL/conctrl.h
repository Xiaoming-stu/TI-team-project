#ifndef __CONCTRL_H
#define __CONCTRL_H

#include "sys.h"

void TIM2_Init(u16 arr, u16 psc);


#endif
