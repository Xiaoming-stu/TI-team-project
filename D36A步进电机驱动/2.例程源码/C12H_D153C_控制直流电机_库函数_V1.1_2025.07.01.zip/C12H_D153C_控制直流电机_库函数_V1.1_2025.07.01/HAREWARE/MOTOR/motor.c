#include "motor.h"

//��ʼ��ֱ�����ٵ����������ת������
void Motor_Init(void)
{
	GPIO_InitTypeDef GPIO_InitStructure;
	
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOA | RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_15;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOA, &GPIO_InitStructure);
	
	GPIO_InitStructure.GPIO_Pin = GPIO_Pin_3 | GPIO_Pin_5 | GPIO_Pin_8 | GPIO_Pin_9;
	GPIO_InitStructure.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIO_InitStructure.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIO_InitStructure);
	
	STBY=1;
	AIN1=0,AIN2=1;
	BIN1=0,BIN2=1;
}

void Motor_mode(u8 mode)
{
	if(mode==0)
	{
		AIN1=0,AIN2=1;
		BIN1=1,BIN2=0;
	}
	else
	{
		AIN1=1,AIN2=0;
		BIN1=0,BIN2=1;
	}
}



