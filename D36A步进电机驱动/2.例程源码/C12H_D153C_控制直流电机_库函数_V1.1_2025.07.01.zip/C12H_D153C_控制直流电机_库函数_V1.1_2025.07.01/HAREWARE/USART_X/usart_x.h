#ifndef __USART_X_H
#define __USART_X_H

#include "sys.h"

void usart1_send(u8 data);
void usart2_send(u8 data);
void Usart1_Init(u32 bound);
void Usart2_Init(void);
void Usart3_Init(u32 bound);

int USART1_IRQHandler(void);
int USART2_IRQHandler(void);
int USART3_IRQHandler(void);






#endif
