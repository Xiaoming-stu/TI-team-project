#ifndef __TIM_H
#define __TIM_H

#include "sys.h"

void TIM2_Init(u16 arr, u16 psc);
void TIM4_Init(u16 arr, u16 psc);
void Set_PWM(int PWMA, int PWMB);

#endif
