#include "conctrl.h"

int TIM6_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM6, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM6, TIM_IT_Update);
		Count++;
		if(Count>=20)
		{
//			Motor_Mode=~Motor_Mode;
			Count=0;
			LED=~LED;
		}
	}
	return 0;
}




