#ifndef __TIM_H
#define __TIM_H

#include "sys.h"

void TIM1_Init(u16 arr, u16 psc);
void TIM8_Init(u16 arr, u16 psc);
void Set_PWM(int PWMA, int PWMB, int PWMC, int PWMD);

#endif
