#include "control.h"

int TIM2_IRQHandler(void)
{
	if(TIM_GetITStatus(TIM2, TIM_IT_Update) != RESET)
	{
		TIM_ClearITPendingBit(TIM2, TIM_IT_Update);
		Sec_Count++;
		if(Sec_Count>=20)
		{
			LED=~LED;
			Sec_Count=0;
		}		
	}
	return 0;
}


