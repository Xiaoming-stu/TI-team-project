#ifndef __ATD5984_H
#define __ATD5984_H

#include "sys.h"

#define ENA				PCout(12)
#define DIRA			PBout(8)
#define PWMA			TIM8->CCR4

#define ENB				PDout(2)
#define DIRB			PBout(9)
#define PWMB			TIM8->CCR3

#define ENC				PBout(5)
#define DIRC			PCout(13)
#define PWMC			TIM8->CCR2

#define END				PBout(4)
#define DIRD			PCout(14)
#define PWMD			TIM8->CCR1




void ATD5984_Init(void);
void STEP12_PWM_Init(u16 arr, u16 psc);



#endif
