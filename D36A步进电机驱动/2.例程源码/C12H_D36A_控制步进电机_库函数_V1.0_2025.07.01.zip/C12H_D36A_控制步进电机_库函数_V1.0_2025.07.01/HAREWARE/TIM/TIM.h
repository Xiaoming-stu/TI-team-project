#ifndef __TIM_H
#define __TIM_H

#include "sys.h"

void TIM2_Init(u16 arr, u16 psc);


#endif
