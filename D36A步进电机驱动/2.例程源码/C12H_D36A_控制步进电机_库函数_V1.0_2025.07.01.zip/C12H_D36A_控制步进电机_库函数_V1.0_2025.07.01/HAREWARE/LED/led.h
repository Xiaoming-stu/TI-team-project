#ifndef __LED_H
#define __LED_H

#include "sys.h"

#define LED  PBout(14)

void LED_Init(void);




#endif
